# Matomo Proxy Hide URL

The proxy script has been moved to [matomo/tracker-proxy](https://github.com/matomo-org/tracker-proxy).
