<?php

echo "This script has been removed, instead use the 'usercountry:attribute' command.\n";
echo "For example, run 'php /path/to/piwik/console usercountry:attribute 2012-01-01,2013-01-01'.\n";
echo "To learn more about the new command, run 'php /path/to/piwik/console help usercountry:attribute'.\n";