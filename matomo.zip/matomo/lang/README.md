## Contribute

If you want to improve an existing Matomo translation or contribute a new translation, please have a look at our [Weblate project](https://hosted.weblate.org/engage/matomo/).

We likely won't accept pull requests for translations on GitHub since we manage all translations in this separate system. Translations will automatically be transferred to GitHub from time to time!

If you have any questions feel free to contact the team at translations@matomo.org.
